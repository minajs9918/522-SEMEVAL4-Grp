#!/usr/bin/env python
# coding: utf-8

# #### 1 Load library package and import Grounded Emotion Dataset
# * In this project "A Word Embedding Approach and Sentiment Analysis on Social News Emotion Data", we can download the dataset online [here](http://web.eecs.umich.edu/~mihalcea/downloads.html#GroundedEmotions) <sup>1</sup>.
# 
# #### Grounded Emotion Data Description
# * A dataset consisting of external factors associated with emotions expressed in tweets, including weather, news events, social network, user predisposition, and timing, used in experiments aiming to show the role played by these factors in predicting emotions.
# > References <br>[1] <i> Grounded emotion dataset </i>, University of Michigan, Dec. 2020. [Online]. Available: http://web.eecs.umich.edu/~mihalcea/downloads.html#GroundedEmotions

# In[2]:


import pandas as pd
from IPython.display import display
tweets = pd.read_csv('data/grounded.csv', header=None, encoding='latin1')
tweets.head(5)


# In[2]:


# adding column name to the respective columns 
tweets.columns =['id1', 'id2', 'sentence', 'created_at', 'tf1', 'fl1', 'fl2', 'tf2'] 

# displaying the DataFrame 
display(tweets.head(5))

# Remove column name except 'sentence'  
tweets2 = tweets.drop(['id1', 'id2', 'created_at', 'tf1', 'fl1', 'fl2', 'tf2'], 
                       axis = 1) 
# show the dataframe 
display(tweets2.head(5))


# In[3]:


# view the shape of the data (the number of rows and columns)
print(f"The shape of the data is: {tweets2.shape}")

# view the data with the "tweet" column widened to 800px 
# so that the full tweet is displayed,
# and hide the index column
tweets2.style.set_properties(subset=['sentence'], **{'width': '800px'}).hide_index()


# #### 2 Preprocess emotion-related hashtag
# * Extract each tweets contain a hashtag.
# * Clean tweets corpora using tqdm package in Python instead using regular expression.
#     * Remove URLs
#     * Remove RT and cc
#     * Remove mentions
#     * Remove punctuations
# * Reduce dimension size by selecting only instances with hashtags.

# In[4]:


# let's find out how many tweets contain a hashtag
tweets_with_hashtags = tweets2.loc[tweets2["sentence"].str.contains("#")]

# view the number of tweets that contain a hashtag
print(f"Number of tweets containing hashtags: {len(tweets_with_hashtags)}")

# view the tweets that contain a hashtag
tweets_with_hashtags.style.set_properties(subset=['sentence'], **{'width': '800px'}).hide_index()  


# In[5]:


import re
def clean_tweet(tweet):
    tweet = re.sub('http\S+\s*', '', tweet)  # remove URLs
    tweet = re.sub('RT|cc', '', tweet)  # remove RT and cc
    tweet = re.sub('#\S+', '', tweet)  # remove hashtags
    tweet = re.sub('@\S+', '', tweet)  # remove mentions
    tweet = re.sub('[%s]' % re.escape("""!"#$%&'()*+,-./:;<=>?@[\]^_`{|}~"""), '', tweet)  # remove punctuations
    tweet = re.sub('\s+', ' ', tweet)  # remove extra whitespace
    return tweet


# In[6]:


tweets_with_hashtags = tweets_with_hashtags.reset_index().drop(['index'], axis = 1)
print(tweets_with_hashtags)


# #### 3 Implement Sentiment score and labelled dataset
# * Manually assigned sentiment ordering. For example, while negative was ‘1’, neutral was ‘2’ and positive was ‘3’.
# * Manually assigned status (emotional status) ordering. For example, while negative was ‘sad’, neutral was ‘unknown’ and positive was ‘happy’.
# * Once the sentiment label of tweets was computed, each statistic had to be summed. 

# In[7]:


import numpy as np
tweets_with_hashtags['sentiment'] = np.NaN
for i in range(len(tweets_with_hashtags)):
    if (str.lower(tweets_with_hashtags['sentence'][i])).find('#happy') != -1:
        tweets_with_hashtags['sentiment'][i] = 'Positive'
    elif (str.lower(tweets_with_hashtags['sentence'][i])).find('#sad') != -1:
        tweets_with_hashtags['sentiment'][i] = 'Negative'
    else:
        tweets_with_hashtags['sentiment'][i] = 'Neutral'


# In[8]:


import seaborn as sns
sns.set(font_scale=1.4)
import matplotlib.pyplot as plt
tweets_with_hashtags['sentiment'].value_counts().plot(kind='barh', facecolor='skyblue', figsize=(8,5)).invert_yaxis() # Plot Histogram
tweets_with_hashtags['sentiment'].value_counts() # Count rows of each sentiments


# In[9]:


from tqdm import tqdm # Clean corpus as regexes do not work

for i in tqdm(range(len(tweets_with_hashtags))):
    tweets_with_hashtags['sentence'][i] = clean_tweet(tweets_with_hashtags['sentence'][i])


# In[10]:


# Create the dictionary 
event_dictionary ={'Negative' : 'Sad', 'Neutral' : 'Unknown', 'Positive' : 'Happy'}
event2_dictionary ={'Negative' : 1, 'Neutral' : 2, 'Positive' : 3}
# Add a new column named 'score' 
tweets_with_hashtags['status'] = tweets_with_hashtags['sentiment'].map(event_dictionary) 
tweets_with_hashtags['score'] = tweets_with_hashtags['sentiment'].map(event2_dictionary) 
# Move 'score' to first column
col_name = 'score'
first_col = tweets_with_hashtags.pop(col_name)
tweets_with_hashtags.insert(0, col_name, first_col)
# Print the DataFrame 
print(tweets_with_hashtags)


# In[11]:


# converting type of columns to 'category'
tweets_with_hashtags['sentiment'] = tweets_with_hashtags['sentiment'].astype('category')
tweets_with_hashtags['status'] = tweets_with_hashtags['status'].astype('category')
# Assigning numerical values and storing in another column
tweets_with_hashtags['sentiment_Cat'] = tweets_with_hashtags['sentiment'].cat.codes
tweets_with_hashtags['status_Cat'] = tweets_with_hashtags['status'].cat.codes
# Print the DataFrame 
print(tweets_with_hashtags)


# #### 4 Modeling
# * Train set (sentiment,e.g negative/neutral/positive and status, e.g. sad/unknown/happy)
# * Test set (score, e.g 1/2/3)
# * Supervised learning methods: <i>Decision Tree</i> <sup>2</sup>, <i>Random Forest</i> <sup>3</sup>, <i>Support Vector Machine</i> <sup>4</sup>
#     * Decision Tree/Random Forest Parameters: `Max depth=1`,`Max depth=5`
#     * Support Vector Machine Parameters: `kernel='linear'`, `kernel='rbf'`, `kernel='sigmoid'`
# 
# > References <br> [2] R. Quinlan, “C4. 5: Programs for Machine Learning. Morgan Kaufmann Publishers,” San Mateo, CA, 1993. <br> [3] V. Liu, C. Banea, and R. Mihalcea, “Grounded emotions,” 2017 7th Int. Conf. Affect. Comput. Intell. Interact. ACII 2017, vol. 2018-Janua, pp. 477–483, 2017.<br> [4] J. C. Platt, “Advances in Kernel Methods of Support Vector Machines: Fast training of support vector machines using sequential minimal optimization.” MIT Press, Cambridge, 1998.

# In[12]:


# import machine learning library to sample the data
from sklearn.model_selection import train_test_split 

x = tweets_with_hashtags.iloc[:,4:]
y = tweets_with_hashtags.iloc[:,:1]
x_train, x_test, y_train, y_test = train_test_split(x,y,test_size=0.30)

# import machine learning library to standardize the data
from sklearn.preprocessing import StandardScaler
sc=StandardScaler()
sc.fit_transform(x_train,y_train)
sc.fit(x_test,y_test)

print('-------- x axis test ----------')
print(x_test)
print('-------- x axis train ---------')
print(x_train)
print('-------- y axis test ----------')
print(y_test)
print('-------- y axis train ---------')
print(y_train)
print('*******************************')


# In[13]:


from sklearn.metrics import accuracy_score, precision_recall_fscore_support
from sklearn.metrics import confusion_matrix
from sklearn.metrics import classification_report
from sklearn.model_selection import cross_val_score
from sklearn.tree import DecisionTreeClassifier

# input the decision tree classifier using "entropy" & train the model
dtree = DecisionTreeClassifier(criterion='entropy', max_depth=1).fit(x_train, y_train)
# predict the classes of new, unseen data
predict = dtree.predict(x_test)
print("The prediction accuracy is: {0:2.2f}{1:s}".format(dtree.score(x_test,y_test)*100,"%"))
# Creates a confusion matrix
print(confusion_matrix(y_test, predict))
print(classification_report(y_test, predict))


# In[14]:


from sklearn.externals.six import StringIO
from IPython.display import Image
from sklearn.tree import export_graphviz
import pydotplus
dot_data = StringIO()
export_graphviz(dtree, out_file=dot_data,
filled=True, rounded=True,
special_characters=True)
graph = pydotplus.graph_from_dot_data(dot_data.getvalue())
Image(graph.create_png())


# In[15]:


from sklearn.ensemble import RandomForestClassifier
num_classifiers = 500

# input the random forest classifier using "gini" & train the model
rf = RandomForestClassifier(n_estimators=num_classifiers,
criterion='gini', max_depth=1)
rf.fit(x_train, y_train)
# predict the classes of new, unseen data
y_pred_rf = rf.predict(x_test)
print("The prediction accuracy is: {0:2.2f}{1:s}".format(rf.score(x_test,y_test)*100,"%"))
# Creates a confusion matrix
print(confusion_matrix(y_test, y_pred_rf))
print(classification_report(y_test, y_pred_rf))


# In[16]:


from sklearn.tree import export_graphviz
import pydot
# Extract single tree
estimator = rf.estimators_[9]

# Export as dot file
dot_data = StringIO()
export_graphviz(estimator, out_file=dot_data,
rounded = True, proportion = False, 
precision = 1, filled = True)

# Use dot file to create a graph
graph = pydotplus.graph_from_dot_data(dot_data.getvalue())

# Display in jupyter notebook
from IPython.display import Image
Image(graph.create_png())


# In[17]:


from sklearn.svm import SVC # "Support vector classifier"

# input the support vector classifier using "kernel" & train the model
SvmLinear = SVC(kernel='linear')
SvmRbf = SVC(kernel='rbf')
SvmSigmoid = SVC(kernel='sigmoid')
SvmLinear.fit(x_train, y_train)
SvmRbf.fit(x_train, y_train)
SvmSigmoid.fit(x_train, y_train)

# predict the classes of new, unseen data
y_predictSvm=SvmSigmoid.predict(x_test)
print("The prediction accuracy is: {0:2.2f}{1:s}".format(SvmLinear.score(x_test,y_test)*100,"%"))
print("The prediction accuracy is: {0:2.2f}{1:s}".format(SvmRbf.score(x_test,y_test)*100,"%"))
print("The prediction accuracy is: {0:2.2f}{1:s}".format(SvmSigmoid.score(x_test,y_test)*100,"%"))

# Creates a confusion matrix
print(confusion_matrix(y_test, y_predictSvm))
print(classification_report(y_test, y_predictSvm))


# #### 5 Testing and Validation

# In[18]:


# get score for the 5 fold cross validation
scoredtree = cross_val_score(dtree, x_train, y_train, cv=5, scoring='accuracy')
scorerf = cross_val_score(rf, x_train, y_train, cv=5, scoring='accuracy')
scoresvm = cross_val_score(SvmSigmoid, x_train, y_train, cv=5, scoring='accuracy')
print("The 5-fold cross-validation score for Decision Tree Classifier is: {0:2.2f}{1:s}".format(scoredtree.mean()*100,"%"))
print("The 5-fold cross-validation score for Random Forest is : {0:2.2f}{1:s}".format(scorerf.mean()*100,"%"))
print("The 5-fold cross-validation score for Support Vector Machine is : {0:2.2f}{1:s}".format(scoresvm.mean()*100,"%"))

